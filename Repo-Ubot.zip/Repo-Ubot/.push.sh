git add .; git commit -m "sego"; git push hydro main
