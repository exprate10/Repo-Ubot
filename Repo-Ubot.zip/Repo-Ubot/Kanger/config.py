#==================================#
#Hijacked by anonymous
#==================================#

DEVS = [7776250726]

DEVICE_MODEL = "KANZ OFFICIAL"

API_ID = 38015719

API_HASH = "cb3ba9897e2d59a14c70aaf3246131c2"

BOT_TOKEN = "8278717959:AAGpf7PBGQADAg72yAI66u80qou73DDL10I"

OWNER_ID = 7776250726

DUMP_LOGS = -1003880340037

USER_ID = 7776250726

LOGS_MAKER_UBOT = -1003880340037

SUPPORT_GROUP = -1003880340037

BLACKLIST_CHAT = [
    -1001473548283,-1001853283409,-1001704645461
    ]

RMBG_API = "3hYYMrCnpDQmAmE81u9aQAz2"

COMMAND = ". ! ? : ;"
PREFIX = COMMAND.split()

MONGO_URL = "mongodb+srv://reon:reon@cluster0.h52cpph.mongodb.net/?retryWrites=true&w=majority"